# Malaria > Dataset_1_to_7_esquerdo
https://universe.roboflow.com/fiocruz/malaria-nq3nz

Provided by a Roboflow user
License: CC BY 4.0

